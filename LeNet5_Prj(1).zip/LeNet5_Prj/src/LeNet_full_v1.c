/**

 * File name: processing.c
 * Author:WWD  Version:V1.0    Date:2020.10.22
 * Description:    ����500x500 RGB���ݣ��Ƚ��м�Ȩ�ҶȻ����ٽ��ж�ֵ����ͼ��ָ
 * 				ͼ����չ��������32x32��ѹ��ͼ��
 * Others:         ����
 * Function List:  // ��Ҫ�����б���ÿ����¼Ӧ���������������ܼ�Ҫ˵��
    1. ....
 * History:        // �޸���ʷ��¼�б���ÿ���޸ļ�¼Ӧ�����޸����ڡ��޸�
                  // �߼��޸����ݼ���
    1. Date:
       Author:
       Modification:
   2. ...
 */

#include "assert.h"
#include <stdint.h>
#include <string.h>
#include "math.h"
#include <ap_cint.h>
#include "lenet.h"

//�ҶȻ���Ȩ����
#define R_value 0.29
#define G_value 0.58
#define B_value 0.11

uint8 Temp[500][500]= {0};

uint8 Res[416][416]= {0};

uint8 IN1[32][32] = {0};
//static float Gray[500][500] = {0};
//static int Binary[500][500] = {0};
//static float Pooling[416][416] = {0};




void lenet(float *In_DRAM, float * Out_DRAM)
{

#pragma HLS INTERFACE s_axilite port=In_DRAM bundle=Ctrl_bus
#pragma HLS INTERFACE m_axi depth=500 port=In_DRAM bundle=Data

#pragma HLS INTERFACE m_axi depth=32 port=Out_DRAM bundle=Data
#pragma HLS INTERFACE s_axilite port=Out_DRAM bundle=Ctrl_bus

#pragma HLS INTERFACE s_axilite port=return bundle=Ctrl_bus

int row=0,col=0,chi=0,cho=0;
int i=0,j=0, c;
uint1 flage=0;
int up_value=0,down_value=0,left_value=0,right_value=0;
int begin1 = 0,begin2=0,end1 = 0,end2=0;


for(row=0;row<500;row++) //��Ȩ�ҶȻ�
{

	for(col = 0;col<500;col++ )
	{

	#pragma HLS PIPELINE
		Temp[row][col] = In_DRAM[row*1500+3*col]*R_value + In_DRAM[row*1500+3*col+1]*G_value +In_DRAM[row*1500+3*col+2]*B_value; //��Լ��Դ��ʹ��IN1[0]�洢�Ҷ�����
	}

}

	for( row=0;row<500;row++) //��ֵ��
		{
			for( col = 0;col<500;col++ )
			{
				if(Temp[row][col]>140)
					Temp[row][col] = 0;
				else
					Temp[row][col] = 255;
			}

		}

	//ͼ��ָ�
	for( row=0;row<500;row++) //����ֵ
			{
				for( col = 0;col<500;col++ )
				{
					if((Temp[row][col]>254)&&(Temp[row+5][col]>254))
						{
							up_value = row;
							flage =1;
							break;
						}

				}
				if(flage == 1)
				{
					flage=0;
					break;

				}
			}

	for( row=0;row<500;row++) //����ֵ
				{
					for( col = 0;col<500;col++ )
					{
						if((Temp[499-row][col]>254)&&(Temp[499-row-5][col] >254))
							{
								down_value = 500-row;
								flage=1;
								break;
							}

					}
					if(flage == 1)
									{
										flage=0;
										break;

									}
				}
	for( col=0;col<500;col++) //����ֵ
					{
						for( row = 0;row<500;row++ )
						{
							if((Temp[row][col]>254)&&(Temp[row][col+5] >254))
								{
									left_value = col;
									flage =1;
									break;
								}

						}
						if(flage == 1)
										{
											flage=0;
											break;

										}

					}

	for(col=0;col<500;col++) //����ֵ
						{
							for( row = 0;row<500;row++ )
							{
								if((Temp[row][499-col]>254)&&(Temp[row][499-col-5] >254))
									{
										right_value = 500-col;
										flage =1;
										break;
									}
							}
							if(flage == 1)
											{
												flage=0;
												break;

											}
						}
//��ͼ���ƶ������м�

	for(row=0;row<416;row++) //���
	{
		for(col=0;col<416;col++)
		{
			Res[row][col] = 0;
		}

	}


	begin1 = (416-(down_value - up_value))/2;
	end1 = begin1 + (down_value - up_value);
	begin2 = (416-(right_value - left_value))/2;
	end2 = begin2 + (right_value - left_value);
	for( row=begin1;row<end1;row++)
		{
#pragma HLS LOOP_TRIPCOUNT min=100 max=416 avg=200
			for( col=begin2;col<end2;col++)
			{
		#pragma HLS LOOP_TRIPCOUNT min=100 max=416 avg=200
					Res[row][col] = Temp[up_value+i][left_value+j];
					j++;
			}
			j=0;
			i++;
		}
	i=0;

	//�ػ���С

	for(row=0;row<32;row++) //���
	{
		for(col=0;col<32;col++)
		{
			IN1[row][col] = 0;
		}

	}

	for( i=0;i<32;i++)
	{
		for( j=0;j<32;j++)
		{
			for( row=0;row<13;row++)
			{
				for( col =0;col<13;col++)
				{
					IN1[i][j] = IN1[i][j] + Res[i*13+row][j*13+col];
					if(IN1[i][j]>254)
					{
						flage = 1;
						break;
					}
				}
				if(flage == 1)
				{
					flage =0;
					IN1[i][j] = 255;
					break;
				}

			}
		}
	}

//����Ϊlenet-5




	//����1
clear1:
	for ( c = 0; c < 6; c++)
	{
		for ( row = 0; row < 28; row++)
		{
			for ( col = 0; col < 28; col++)
			{
							OUT1[c][row][col] =0; //����
			}
		}
	}




for ( c = 0; c < 6; c++)
{
	for ( row = 0; row < 28; row++)
	{
		for ( col = 0; col < 28; col++)
		{
		row1:
			for ( i = 0; i < 5; i++)
			{
			cow1:
				for ( j = 0; j < 5; j++)
				{
						OUT1[c][row][col] += IN1[row + i][col + j] * W1[c][i][j];
				}
			}
		}
	}
}

	//�������ReLU
	active_r1:
	for ( row = 0; row < 28; row++)
	{
	active_c1:
		for ( col = 0; col < 28; col++)
		{
			for ( c = 0; c < 6; c++)
			{
				OUT1[c][row][col] = (OUT1[c][row][col] + Bias1[c]) > 0 ? (OUT1[c][row][col] + Bias1[c]) : 0;
			}
		}
	}

	//���ػ�
pool_r1:
	for ( row = 0; row < 14; row++)
	{
	pool_c1:
		for ( col = 0; col < 14; col++)
		{
			for ( c= 0; c < 6; c++)
			{
				float temp1, temp2, temp3;
				temp1 = OUT1[c][row * 2 + 0][col * 2 + 0]>OUT1[c][row * 2 + 0][col * 2 + 1]?OUT1[c][row * 2 + 0][col * 2 + 0]:OUT1[c][row * 2 + 0][col * 2 + 1];
				temp2 = OUT1[c][row * 2 + 1][col * 2 + 0]>OUT1[c][row * 2 + 1][col * 2 + 1]?OUT1[c][row * 2 + 1][col * 2 + 0]:OUT1[c][row * 2 + 1][col * 2 + 1];
				temp3 = temp1>temp2?temp1:temp2;
				IN2[c][row][col] = temp3;

			}
		}
	}



 //�ڶ��ξ��������룺6x14x14,ͨ��16�������ˣ���16��ƫ�ã����16x10x10

	for ( col = 0; col < 10; col++)//������
	{
	clear2:
		for ( row = 0; row < 10; row++)
		{
			for ( i = 0; i < 16; i++)
			{
				OUT2[i][row][col] = 0;
			}
		}
	}

			for ( row = 0; row < 5; row++) //16*6*5*5
			{
				for ( col = 0; col < 5; col++)
				{
				roW23:
					for (i = 0; i < 10; i++)
					{
					col2:
						for ( j = 0; j < 10; j++)
						{
							for ( chi = 0; chi < 16; chi++) //��������,��Ӧ�������
							{
								for ( cho = 0; cho < 6; cho++) //ÿ��������ά�ȣ�ÿ��ά�ȷֱ�����������
								{
									OUT2[chi][i][j] += IN2[cho][i + row][j + col] * W2[chi][cho][row][col];
								}
							}

						}
					}
				}
			}


	active_r2: //����
	for ( row = 0; row < 10; row++)
	{
	active_c2:
		for ( col = 0; col < 10; col++)
		{
			for (int cho = 0; cho < 16; cho++)
			{
				OUT2[cho][row][col] = (OUT2[cho][row][col] + Bias2[cho]) > 0 ? (OUT2[cho][row][col] + Bias2[cho]) : 0;
			}
		}
	}

	//�ػ�
	pool_r2:
	for ( row = 0; row < 5; row++)
	{
	pool_c2:
		for ( col = 0; col < 5; col++)
		{
			for ( cho = 0; cho < 16; cho++)
			{

				float temp1, temp2, temp3;
				temp1 = OUT2[cho][row * 2 + 0][col * 2 + 0]>OUT2[cho][row * 2 + 0][col * 2 + 1]?OUT2[cho][row * 2 + 0][col * 2 + 0]:OUT2[cho][row * 2 + 0][col * 2 + 1];
				temp2 = OUT2[cho][row * 2 + 1][col * 2 + 0]>OUT2[cho][row * 2 + 1][col * 2 + 1]?OUT2[cho][row * 2 + 1][col * 2 + 0]:OUT2[cho][row * 2 + 1][col * 2 + 1];
				temp3 = temp1>temp2?temp1:temp2;
				IN3[cho][row][col] = temp3;
			}
		}
	}


	//�����ξ��������룺16x5x5�������120x1x1,������Ϊ 120x16x5x5

	clear3:
	for ( i = 0; i < 120; i++)
	{
		OUT3[i] = 0;
	}

	for ( i = 0; i < 120; i++)
	{
		kr3:
			for ( row = 0; row < 5; row++)
			{
			kc3:
				for ( col = 0; col < 5; col++)
				{
					cho3:for ( chi = 0; chi < 16; chi++)
					{
							OUT3[i] += IN3[chi][row][col] * W3[i][chi][row][col];
					}
				}
			}
		}

	active3:
	for ( cho = 0; cho < 120; cho++)
	{
		float temp;
		temp = OUT3[cho] + Bias3[cho];
		OUT3[cho] = temp > 0 ? temp : 0;
	}


	clear4:for (i = 0; i < 84; i++)
	{
		OUT4[i] = 0;
	}

	fc6_cho:
	for ( cho = 0; cho < 84; cho++) //����120���84
	{
		fc6_chi:
		for ( chi = 0; chi < 120; chi++)
		{

			OUT4[cho] += OUT3[chi] * W4[cho][chi];

		}
	}

	fc6_active:
	for ( cho = 0; cho < 84; cho++)
	{
		OUT4[cho] = (OUT4[cho] + Bias4[cho]) > 0 ? (OUT4[cho] + Bias4[cho]) : 0;
	}

	clear5:for (i = 0; i < 10; i++)
		{
			OUT5[i] = 0;
		}

	fc7_chi:
	for ( chi = 0; chi < 10; chi++)
	{
		fc7_cho:
		for ( cho = 0; cho < 84; cho++)
		{
			OUT5[chi] += OUT4[cho] * W5[chi][cho];
		}

	}

	fc7_active:
		for ( cho = 0; cho < 10; cho++)
		{

			OUT5[cho] = (OUT5[cho] + Bias5[cho]) > 0 ? (OUT5[cho] + Bias5[cho]) : 0;

		}



	memcpy((void*)(Out_DRAM), (const void*)OUT5, sizeof(float) * 10);


}
